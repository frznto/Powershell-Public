These .p12 files are placeholder test artifacts created for UI/workflow testing.
They are NOT valid PKCS#12 bundles and will not extract with OpenSSL.
Use them to validate folder enumeration, logging, and UX flows.
p12 password is TestPfx!2025
